<html>
    <body>
        <form action="#" method="POST">
            <label> email</label>
            <input type="text" name="email"><br>
            <label> pass</label>
            <input type="password" name="pass"><br>
            <label> confirm pass</label>
            <input type="password" name="conpass"><br>
            <input type="submit">
        </form>
</body>
<?php
if(!empty($_POST["email"]) && !empty($_POST["pass"]) && !empty($_POST["conpass"]))
{
    $user = $_POST["email"];
    $pass = $_POST["pass"];
    $conpass = $_POST["conpass"];
    if($pass==$conpass)
    {
        $conn = new mysqli("localhost","root","krishna","lib");
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
          }
          $sql = "insert into user values('$user','$pass')";
          if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
          } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
          }
          $conn->close();
    }
    else{
        echo "pass should be same";
    }
}
else{
    echo "<h1>Enter all details</h1>";
}
?>
</html>