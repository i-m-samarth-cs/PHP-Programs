<?php
    session_start();
?>
<html>
    <body>

        <?php 
        if(isset($_SESSION["user"]) && isset($_SESSION["valid"]))
        {
            if($_SESSION["user"]=="admin" && $_SESSION["valid"])
            {
                echo "<p> Admin Login Successfully</p>";
                echo "<h1>add another User</h1>";
                echo "<h1> Delete User</h1> ";
            }
        }   
        else{
            echo "<h1>Please Login and come back again</h1> ";
            echo "<a href='http://localhost/unit4/login/login.php'>Click for LOGIN</a>";
        }
        ?>
    </body>
</html>