<?php
if(isset($_COOKIE["count"])) {
    //$_COOKIE["count"] = $_COOKIE["count"]+1;
    $var = $_COOKIE["count"]+1;
    setcookie("count",$var,time()+(24*60*60*30));
    echo "count=".$_COOKIE["count"];
}
else{
    echo "Value of Cookie is not set or Deleted<br>";
}
?>