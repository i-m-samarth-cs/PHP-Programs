<html>
<?php
    $days = 30;
    $ret = setcookie("count", "1", 
    time() + (24*60*60*$days),"/");
    if($ret){
        echo "<h1>Cookie for count is set/reset with value 1</h1>";
    }
?>
</html>