<?php
if(isset($_COOKIE["count"])){
    $var = setcookie("count","0",time()-1);
    if($var){
        echo "<h1>Cookie deleted successfully</h1>";
    }
}
else{
    echo "Value of Cookie is not set or Deleted<br>";
}
?>