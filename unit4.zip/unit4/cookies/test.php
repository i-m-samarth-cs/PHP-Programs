<?php
    echo time();
?>