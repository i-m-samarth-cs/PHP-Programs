<?php
echo "<h1>Tell me which server side lang it is?</h1>"
?>