<?php
    $name = $_GET["test_name"];
    $address = $_GET["test_address"];
    $submit = $_GET["test_submit"];
    
    echo "<html><body>My name is ".$name;
    echo "<br>I live in ". $address."</body></html>";
?>