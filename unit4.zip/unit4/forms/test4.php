<?php
    $name = $_GET["cars"];
    var_dump($name);
?>