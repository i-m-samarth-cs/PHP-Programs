<?php
    $name = $_GET["vehicle"];
    var_dump($name);
?>