<?php
    $name = $_GET["lang"];
    var_dump($name);
?>