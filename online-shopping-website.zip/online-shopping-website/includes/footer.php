




        <footer class="foot">
           <div class="container">
               <center>
                   <p>Copyright <small>&copy;</small> Lifestyle Store | All Rights Reserved.</p>
               </center>
           </div>
           
           
       </footer>   
        
        
        
       
